import { useState } from "react";
import { motion } from "framer-motion";
import { Heart, HeartHandshake } from "lucide-react";
import { ValentineButton } from "../components/ui/valentine-button";
import { 
  CelebrationModal } from '../components/ui/celebration-modal';



export default function Home() {
  const [showCelebration, setShowCelebration] = useState(false);
  const [noButtonPosition, setNoButtonPosition] = useState({ x: 0, y: 0 });

  const handleYesClick = () => {
    setShowCelebration(true);
  };

  const handleNoHover = () => {
    const newX = Math.random() * 150 - 75;
    const newY = Math.random() * 150 - 75;
    setNoButtonPosition({ x: newX, y: newY });
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-dark p-4">
      {/* Картинка котиков */}
      <img 
        src="/love-cat.gif"
        alt="Cute Cat"
        className="w-32 h-32 mx-auto mb-4 rounded-lg shadow-lg"
      />

      {/* Заголовок */}
      <h1 className="text-4xl md:text-5xl font-bold text-primary mb-8">
        Will you be my Valentine?
      </h1>

      {/* Кнопки */}
      <div className="flex flex-col md:flex-row gap-4 items-center justify-center">
        {/* Кнопка "Yes" */}
        <ValentineButton
          onClick={handleYesClick}
          className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-purple-500 hover:to-blue-500 text-white px-6 py-2 rounded-full shadow-md text-lg font-semibold transform transition duration-300 hover:scale-110"
        >
          Yes
        </ValentineButton>

        {/* Кнопка "No" с анимацией перемещения */}
        <motion.div animate={noButtonPosition} transition={{ type: "spring", stiffness: 200, damping: 20 }}>
          <ValentineButton
            onMouseEnter={handleNoHover}
            className="bg-gradient-to-r from-red-500 to-pink-500 hover:from-pink-500 hover:to-red-500 text-white px-6 py-2 rounded-full shadow-md text-lg font-semibold transform transition duration-300 hover:scale-110"
          >
            No
          </ValentineButton>
        </motion.div>
      </div>

      {/* Модальное окно */}
      <CelebrationModal open={showCelebration} onClose={() => setShowCelebration(false)} />
    </div>
  );
}
