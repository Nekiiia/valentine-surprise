import { motion } from "framer-motion";
import { Button } from "@radix-ui/themes";

interface ValentineButtonProps {
  children: React.ReactNode;
  variant: "yes" | "no"; // Выбор стиля кнопки
  [key: string]: any;
}

export function ValentineButton({ children, variant, ...props }: ValentineButtonProps) {
  const buttonStyles = {
    yes: {
      background: "linear-gradient(202deg, rgba(196,145,215,1) 29%, rgba(153,100,173,1) 62%)",
    },
    no: {
      background: "linear-gradient(202deg, rgba(88,124,176,1) 29%, rgba(100,147,173,1) 62%)",
    },
  };

  return (
    <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
      <Button
        {...props}
        className="px-6 py-3 text-lg font-semibold text-white rounded-full shadow-lg transition"
        style={buttonStyles[variant]}
      >
        {children}
      </Button>
    </motion.div>
  );
}